import {FC} from 'react';
import IconProps from "./InterfaceIcons";

const DownloadIcon: FC<IconProps> = (props) => {
    return (<svg xmlns="http://www.w3.org/2000/svg" 
                 width="53" height="53" fill="none" viewBox="0 0 24 24"
                 stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5"/>
            </svg>
  )
}


export default DownloadIcon;