import {FC} from 'react';
import IconProps from "./InterfaceIcons";

const AddProjectIcon: FC<IconProps> = () => {
    return (<svg xmlns="http://www.w3.org/2000/svg"
                 width="54" height="54" fill="none" viewBox="0 0 24 24"
                 stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                 <path d="M3 3h18v18H3zM12 8v8m-4-4h8"/>
            </svg>
  )
}

export default AddProjectIcon;