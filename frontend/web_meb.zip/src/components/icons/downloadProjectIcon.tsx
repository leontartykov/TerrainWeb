import {FC} from 'react';
import IconProps from "./InterfaceIcons";

const DownloadProjectIcon: FC<IconProps> = () => {
    return (<svg xmlns="http://www.w3.org/2000/svg" 
                 width="40" height="40" fill="none" viewBox="-4 -2 33 33"
                 stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5"/>
            </svg>
  )
}


export default DownloadProjectIcon;