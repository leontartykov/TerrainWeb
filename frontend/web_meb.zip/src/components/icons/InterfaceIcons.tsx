interface IconProps{
    title?: string,
    width?: string,
    height?: string,
    fill?: string
}

export default IconProps;