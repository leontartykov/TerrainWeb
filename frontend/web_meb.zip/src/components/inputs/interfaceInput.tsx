interface InputProps{
    title?: string,
    width?: string,
    height?: string,
    fill?: string
}

export default InputProps;