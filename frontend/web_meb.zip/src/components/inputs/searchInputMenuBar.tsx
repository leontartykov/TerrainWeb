import {FC} from 'react';
import InputProps from 'components/inputs/interfaceInput'
import inputStyles from 'components/inputs/inputs.module.scss';

export const InputSearchProjectsMenuBar: FC<InputProps> = () =>
{
    return (
        <div>
            <input className={inputStyles.seacrhProject} placeholder="Искать..."></input>
        </div>
    )
}