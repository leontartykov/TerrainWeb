import layoutStyles from 'components/layouts/layouts.module.scss'
import {TerrainButton} from 'components/buttons/terrainButton'
import {AllMyProjectsButton} from 'components/buttons/allMyProjectsButton'
import {ReturnBackButton} from 'components/buttons/returnBackButton'

export const GroupAllMyProjectsMainMenuReturnBack = () =>
{
    return (
        <form className={layoutStyles.allMyProjectsMainMenu}>
            <div><TerrainButton></TerrainButton></div>
            <div><AllMyProjectsButton></AllMyProjectsButton></div>
            <div><ReturnBackButton></ReturnBackButton></div>
        </form>
    )
}