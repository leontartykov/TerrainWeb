import {InputSearchProjectsMenuBar} from 'components/inputs/searchInputMenuBar'
import {SignUpButton} from 'components/buttons/signUpButton'
import layoutStyles from 'components/layouts/layouts.module.scss'

export const GroupSearchSignUpButtonLayouted = () =>
{
    return (
        <form className={layoutStyles.wrapper}>
            <div><InputSearchProjectsMenuBar></InputSearchProjectsMenuBar></div>
            <div><SignUpButton></SignUpButton></div>
        </form>
    )
}