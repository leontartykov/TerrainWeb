import layoutStyles from 'components/layouts/layouts.module.scss'
import {TerrainButton} from 'components/buttons/terrainButton'
import {AllMyProjectsButton} from 'components/buttons/allMyProjectsButton'

export const GroupAllMyProjectsMainMenu = () =>
{
    return (
        <form className={layoutStyles.allMyProjectsMainMenu}>
            <div><TerrainButton></TerrainButton></div>
            <div><AllMyProjectsButton></AllMyProjectsButton></div>
        </form>
    )
}