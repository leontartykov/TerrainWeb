import {GroupSearchSignUpButtonLayouted} from 'components/layouts/groupSearchSignUpButtonLayouted'
import layoutStyles from 'components/layouts/layouts.module.scss'
import {GroupSearchSignInUserNameButton} from 'components/layouts/groupSearchSignInButtonLayouted'
import {GroupAllMyProjectsMainMenu} from 'components/layouts/groupAllMyProjectsMainMenu'

export const MenuBarAuthorizedAllprojects = () =>
{
    return(
        <form className={layoutStyles.rectangle}>
            <GroupAllMyProjectsMainMenu></GroupAllMyProjectsMainMenu>
            <GroupSearchSignInUserNameButton></GroupSearchSignInUserNameButton>
        </form>
    ) 
}