import {GroupSearchSignUpButtonLayouted} from 'components/layouts/groupSearchSignUpButtonLayouted'
import layoutStyles from 'components/layouts/layouts.module.scss'
import {GroupSearchSignInUserNameButton} from 'components/layouts/groupSearchSignInButtonLayouted'
import {GroupAllMyProjectsMainMenuReturnBack} from 'components/layouts/groupAllMyProjectsMainMenuReturnBack'

export const MenuBarAuthorizedReturn = () =>
{
    return(
        <form className={layoutStyles.rectangle}>
            <GroupAllMyProjectsMainMenuReturnBack></GroupAllMyProjectsMainMenuReturnBack>
            <GroupSearchSignInUserNameButton></GroupSearchSignInUserNameButton>
        </form>
    ) 
}