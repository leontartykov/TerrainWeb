import layoutStyles from 'components/layouts/layouts.module.scss'
import {TerrainButton} from 'components/buttons/terrainButton'
import {ReturnBackButton} from 'components/buttons/returnBackButton'

export const GroupMainMenuReturnBack = () =>
{
    return (
        <form className={layoutStyles.allMyProjectsMainMenu}>
            <div><TerrainButton></TerrainButton></div>
            <div><ReturnBackButton></ReturnBackButton></div>
        </form>
    )
}