import {InputSearchProjectsMenuBar} from 'components/inputs/searchInputMenuBar'
import {LogoutButton} from 'components/buttons/logoutButton'
import layoutStyles from 'components/layouts/layouts.module.scss'

export const GroupSearchSignInUserNameButton = () =>
{
    return (
        <form className={layoutStyles.wrapper}>
            <div><h2>user11</h2></div>
            <div><InputSearchProjectsMenuBar></InputSearchProjectsMenuBar></div>
            <div><LogoutButton></LogoutButton></div>
        </form>
    )
}