import {GroupSearchSignUpButtonLayouted} from 'components/layouts/groupSearchSignUpButtonLayouted'
import layoutStyles from 'components/layouts/layouts.module.scss'
import { Resizable } from 'react-resizable';
import {TerrainButton} from 'components/buttons/terrainButton'

export const MenuBarUnauthorizedLayouted = () =>
{
    return(
        <form className={layoutStyles.rectangle}>
            <TerrainButton></TerrainButton>
            <GroupSearchSignUpButtonLayouted></GroupSearchSignUpButtonLayouted>
        </form>
    ) 
}