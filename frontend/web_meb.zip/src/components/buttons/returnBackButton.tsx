import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'
import ReturnBackIcon from 'components/icons/returnBackIcon';

export const ReturnBackButton: FC<IButtonProps> = (props) => {
    return (
        <button className={styles.allSmallButton}> 
            <ReturnBackIcon></ReturnBackIcon>
        </button>
    )
}