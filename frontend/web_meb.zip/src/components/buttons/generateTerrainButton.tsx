import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'

export const GenerateTerrainButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.generateTerrain}>
          <h2 className={fonts.titleText}> Сгенерировать</h2>
        </button>
    )
}