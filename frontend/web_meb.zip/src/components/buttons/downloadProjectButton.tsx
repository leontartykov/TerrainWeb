import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import DownloadProjectIcon from 'components/icons/downloadProjectIcon';

export const DownloadProjectButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.downloadTerrain}> 
            <DownloadProjectIcon></DownloadProjectIcon>
        </button>
    )
}