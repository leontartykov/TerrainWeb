import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'

export const SelectMyProjectsButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.mainMenuSelectProjects}>
          <h2 className={fonts.selectMyProjects}> Мои проекты</h2>
        </button>
    )
}

export const SelectOtherProjectsButton: FC<IButtonProps> = () => {
  return (
    <button className={styles.mainMenuSelectProjects}>
      <h2 className={fonts.selectOtherProjects}> Другие проекты</h2>
    </button>
  )
}