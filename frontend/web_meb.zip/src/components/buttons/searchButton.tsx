import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import SearchIcon from 'components/icons/searchIcon';

export const SearchButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.allSmallButton}> 
            <SearchIcon></SearchIcon>
        </button>
    )
}
