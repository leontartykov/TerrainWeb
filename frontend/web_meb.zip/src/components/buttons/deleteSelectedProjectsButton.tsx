import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import DeleteSelectedProjectsIcon from 'components/icons/deleteSelectedProjectsIcon';

export const DeleteSelectedProjectsButton: FC<IButtonProps> = (props) => {
    return (
        <button className={styles.allSmallButton}> 
            <DeleteSelectedProjectsIcon></DeleteSelectedProjectsIcon>
        </button>
    )
}