import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import LogoutIcon from 'components/icons/logoutIcon';

export const LogoutButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.allSmallButton}> 
            <LogoutIcon></LogoutIcon>
        </button>
    )
}