import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'

export const SignInButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.signIn}>
          <h2 className={fonts.signInText}> Войти</h2>
        </button>
    )
}

export const SignInInputPageButton: FC<IButtonProps> = () => {
  return (
    <button className={styles.userInputInfoButton}>
      <h2 className={fonts.userInputInfoSingIn}> Войти</h2>
    </button>
  )
}