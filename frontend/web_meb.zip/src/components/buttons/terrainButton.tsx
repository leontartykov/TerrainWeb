import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'

export const TerrainButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.terrainMainMenu}>
          <h2 className={fonts.terrainText}>Ландшафт</h2>
        </button>
    )
}