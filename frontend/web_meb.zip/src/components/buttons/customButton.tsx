import React from "react";

interface IButtonProps{
    width?: string;
    height?: string;
    border?: string;
    color?: string;
    radius?: string;
    onClick?: () => void;
}

export default IButtonProps;