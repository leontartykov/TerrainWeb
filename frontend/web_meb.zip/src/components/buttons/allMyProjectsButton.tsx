import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'
import AllMyProjectsIcon from 'components/icons/allMyProjectsIcon';

export const AllMyProjectsButton: FC<IButtonProps> = (props) => {
    return (
        <button className={styles.allSmallButton}> 
            <AllMyProjectsIcon></AllMyProjectsIcon>
        </button>
    )
}