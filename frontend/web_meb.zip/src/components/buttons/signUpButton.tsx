import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import fonts from 'components/fonts/fonts.module.scss'

export const SignUpButton: FC<IButtonProps> = () => {
    return (
        <button className={styles.registration}> 
            <h2 className={fonts.signUpText}> Регистрация</h2>
        </button>
    )
}

export const SignUpInputPageButton: FC<IButtonProps> = () => {
    return (
      <button className={styles.userInputInfoButton}>
        <h2 className={fonts.userInputInfoSignUp}> ЗАРЕГИСТРИРОВАТЬСЯ</h2>
      </button>
    )
  }