import {FC} from 'react';
import IButtonProps from "./customButton";
import styles from 'components/buttons/buttons.module.scss';
import AddProjectIcon from 'components/icons/addProjectIcon';

export const AddProjectButton: FC<IButtonProps> = (props) => {
    return (
        <button className={styles.allSmallButton}> 
            <AddProjectIcon></AddProjectIcon>
        </button>
    )
}